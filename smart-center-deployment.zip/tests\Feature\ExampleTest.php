<?php

namespace Tests\Feature;

// use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     */
    public function test_the_application_returns_a_successful_response(): void
    {
        $response = $this->get('/');

        // الصفحة الرئيسية تعيد توجيه للـ dashboard أو login
        $this->assertTrue(in_array($response->status(), [200, 302]));
    }
}
